package Exercice2;

public class Point {
	private String name;
	private int abs;
	private int ord;
	
public Point (int x,int y) {
	this.abs =x;
	this.ord = y;
	
}
public Point(String z)
{
	this.name= z;
}
public Point(String z,int x,int y)
{
	this.name=z;
	this.abs = x;
	this.ord = y;
}
public void afficher()
{
	System.out.println(name+"("+abs+","+ord+")");
}
public void TransHoriz(int a)
{
	abs += a;
}
public void TranslVert (int a)
{
	ord += a;
}
public void Translation (int a, int b)
{
	abs += a;
	ord += b;
}
public boolean Coïncide (Point p)
{
	if(abs == p.abs && ord == p.ord)
	{
		return true;
	}
	else
	{
		return false;
	}
	
}
public String getNom()
{
	return name;
}
public int getAbscisse()
{
	return abs;
}
public int getOrdonnée()
{
	return ord;
}
public void setNom(String ch)
{
	this.name = ch;
}
public void setAbscisse(int a)
{
	this.abs = a;
}
public void setOrdonnée(int a)
{
	this.ord = a;
}
}
