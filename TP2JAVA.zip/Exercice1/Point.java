package TP2;

public class Point {
	private char id;
	private double abs;

public Point (char c, double x) {
	id = c ;
	abs = x ;
}
public void affiche ()
{ 
	
	System.out.println("Point identifié par "+this.id+" est d\'abscisse "+this.abs);
}
public void translate (double dx)
{ abs += dx ; 

}


public static void main (String args[]) 
{
		Point a = new Point ('A',2.5) ;
		a.affiche() ;
		Point b = new Point ('B', 5.25) ;
		b.affiche() ;
		b.translate(2.25) ;
		b.affiche() ;
}

}