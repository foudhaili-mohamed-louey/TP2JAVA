package Exercice3;

public class MaDate {
    private int Jours;
    private int Mois;
    private int Année;
    
    public MaDate(int jour, int mois, int annee) {
        this.Jours = jour;
        this.Mois = mois;
        this.Année = annee;
    }
    
    
    public MaDate(int annee) {
        this.Jours = 1;   
        this.Mois = 1;    
        this.Année = annee;
    }
    
    
    public int getJour() {
        return Jours;
    }
    
    
    public int getMois() {
        return Mois;
    }
    
    
    public int getAnnee() {
        return Année;
    }
    
    
    public void setJour(int x) {
        this.Jours = x;
    }
    
    
    public void setMois(int x) {
        this.Mois = x;
    }
    
    
    public void setAnnee(int x) {
        this.Année = x;
    }
    
    
   
    public String toString() {
        String dateStr = "";
        
        if (this.Jours < 10) {
            dateStr += "0" + this.Jours + "/";
        } else {
            dateStr += this.Jours + "/";
        }
        
        if (this.Mois < 10) {
            dateStr += "0" + this.Mois + "/";
        } else {
            dateStr += this.Mois + "/";
        }
        
        dateStr += this.Année;
        return dateStr;
    }
    
    
    public void ajouterUnJour() {
        int resultat = this.Jours + 1;
        
        if (this.Mois == 2) {
            if (this.Année % 4 != 0) {
                if (resultat > 28) {
                    this.Jours = 1;
                    this.Mois++;
                } else {
                    this.Jours = resultat;
                }
            } else {
                if (resultat > 29) {
                    this.Jours = 1;
                    this.Mois++;
                } else {
                    this.Jours = resultat;
                }
            }
        }
        else if (resultat > 30 && (this.Mois == 4 || this.Mois == 6 || this.Mois == 9 || this.Mois == 11)) {
            this.Jours = 1;
            this.Mois++;
        }
        else if (resultat > 31 && (this.Mois == 1 || this.Mois == 3 || this.Mois == 5 || this.Mois == 7 || this.Mois == 8 || this.Mois == 10 || this.Mois == 12)) {
            this.Jours = 1;
            this.Mois++;
            if (this.Mois > 12) {
                this.Mois = 1;
                this.Année++;
            }
        }
        else {
            this.Jours = resultat;
        }
    }
    
    
    public void ajouterjours(int n) {
        for (int i = 0; i < n; i++) {
            ajouterUnJour();
        }
    }
    
    
    public void ajouterUnMois() {
        this.Mois++;
        if (this.Mois > 12) {
            this.Mois = 1;
            this.Année++;
        }
    }
    
    
    public void ajouterUnAn() {
        this.Année++;
    }
}
