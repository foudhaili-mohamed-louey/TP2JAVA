package Exercice3;

import java.util.Scanner;

public class TestDate {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MaDate d1 = new MaDate(2, 3, 2024);
        MaDate d2 = new MaDate(2, 3, 2024);
        MaDate d3 = new MaDate(15);

        System.out.println("Dates initiales:");
        
      
        String res1 = d1.toString();
        System.out.println(res1 + "\n");
        
        String res2 = d2.toString();
        System.out.println(res2 + "\n");
        
        String res3 = d3.toString();
        System.out.println(res3 + "\n");
        
        
        int x1 = d1.getJour();
        int x2 = d1.getMois();
        int x3 = d1.getAnnee();
        
        int y1 = d2.getJour();
        int y2 = d2.getMois();
        int y3 = d2.getAnnee();
        
        
        if (x1 == y1 && x2 == y2 && x3 == y3) {
            System.out.println("les deux dates sont identiques");
        } else {
            System.out.println("les deux dates ne sont pas identiques");
        }
        
        
        System.out.println("donner le choix : \n1) Ajout d'un jour\n2)ajout plusieur jours\n3)Ajout d'un mois\n4)ajout d'une année\n5)stop the app\n");
        
        boolean test = true;
        while(test)
        {
        	int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    d1.ajouterUnJour();
                    
                    System.out.println(d1.toString());
                    break;
                case 2:
                    System.out.print("Entrez le nombre de jours à ajouter: ");
                    int jours = sc.nextInt();
                    d1.ajouterjours(jours);
                    
                    System.out.println(d1.toString());
                    break;
                case 3:
                    d1.ajouterUnMois();
                   
                    System.out.println(d1.toString());
                    break;
                case 4:
                    d1.ajouterUnAn();
                    
                    System.out.println(d1.toString());
                    break;
                case 5:
                	test =false;
                	break;
                default:
                    System.out.println("Choix invalide");
                    break;
            }
        }
     
        
        sc.close();
    }
}
